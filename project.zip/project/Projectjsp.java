package First;
import java.io.*;
import java.sql.*;
import java.util.*;


public class Projectjsp
{
	public Connection conn;
	public PreparedStatement pst;
	String driver = "com.mysql.jdbc.Driver";
	String url = "jdbc:mysql://10.0.0.22:3306/workarea";
	String name = "sravs";
	String psswd = "tecnics";
	public Projectjsp()
	{
		try
		{
			Class.forName(driver).newInstance();
			conn = DriverManager.getConnection(url, name, psswd);
		}catch(Exception e)
		{
			e.printStackTrace();
			// System.out.println(e);
		}
	}
	public void insert(String sql)
	{
		try
		{
			// Statement st = conn.createStatement();
			// PreparedStatement pst = conn.prepareStatement(sql);
			pst = conn.prepareStatement(sql);
			pst.execute();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e);
		}
	}
	public void update(String sql)
	{
		try
		{
			// Statement st = conn.createStatement();
			// PreparedStatement  pst = conn.prepareStatement(sql);
			pst = conn.prepareStatement(sql);
			pst.execute();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e);
		}
	}
	public void delete(String sql)
	{
		try
		{
			// Statement st = conn.createStatement();
			// PreparedStatement pst = conn.prepareStatement(sql);
			pst = conn.prepareStatement(sql);
			pst.execute();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e);
		}
	}
	public ArrayList search(String sql)
	{
		ArrayList<String>  alist = new ArrayList<String>();
		ResultSet rset = null;
		try
		{
			Statement st = conn.createStatement();
			rset = st.executeQuery(sql);
			// PreparedStatement pst = conn.prepareStatement(sql);
			// rset = conn.prepareStatement(sql);
		
			ResultSetMetaData rsetdata = rset.getMetaData();
			int colcount = rsetdata.getColumnCount();
			
			while(rset.next())
			{
				for(int i=1;i<=colcount;i++)
				{
					alist.add(rset.getString(i));
				}
			}
			return alist;

		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e);
		}
		finally
		{
			return alist;
		}
	}
	public ArrayList display(String sql)
	{		
			ArrayList<String> alist = new ArrayList<String>();
			ResultSet rset = null;
			try
			{
			// pst = conn.prepareStatement(sql);
			Statement st = conn.createStatement();
			rset = st.executeQuery(sql);
			ResultSetMetaData rsetdata =  rset.getMetaData();
			int colcount = rsetdata.getColumnCount();
			// ResultSet rset = st.executeQuery(sql);
			
				
				while(rset.next())
				{
					for(int i=1;i<=colcount;i++)
					{
						alist.add(rset.getString(i));
					}
				}
				return alist;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println(e);
			}
			finally
			{
				return alist;
			}

	}
}


