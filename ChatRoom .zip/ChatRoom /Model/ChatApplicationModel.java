
	/******************************************************************************************** /
   /	       CHAT ROOM Web Based Application devloped in TECNICS lab on 6-8-2015               /
  /*********************************************************************************************/ 

package Chat;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.util.Arrays;

public class ChatApplicationModel
{
	public static Statement statement=null;
	public static ResultSet result=null;
	public static Connection connect=null;
	public static PreparedStatement preparestmnt=null;
	public static boolean found=false;

	public static String query;	
	public static String id; 
	public static String pwd;
	public static String uname;
	public static int num;
	public static String date;
	public static String time;
	public static String msg;
	public static String status;
	
	public ChatApplicationModel()throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		connect=DriverManager.getConnection("jdbc:mysql://10.0.0.17:3306/DBTextMe","ashok","tecnics");
		statement=connect.createStatement();	
	}
	public static String registerWithChatRoomDB(String id,String pwd,String uname) throws Exception
	{
		query="select * from tblTextMeUser where UserId='"+id+"'";
		preparestmnt=connect.prepareStatement(query);
		result=preparestmnt.executeQuery();
		found=result.next();
		if(found)
		{
			status="Account already exist .. please try to login !!";
		}
		else
		{
			query="insert into tblTextMeUser values('"+id+"','"+pwd+"','"+uname+"')";
			statement.executeUpdate(query);
			status="Registration Successfully Completed";
		}	
		return status;	
	}
	public static Boolean loginValidationWithChatRoomDB(String id,String pwd) throws Exception
	{
		query="select * from tblTextMeUser where UserId='"+id+"' and Password='"+pwd+"'";
		preparestmnt=connect.prepareStatement(query);
		result=preparestmnt.executeQuery();
		found=result.next();
		return found;	
	}	
	public static String saveMsgIntoChatRoomDB(String id,String msg) throws Exception
	{
		query="insert into tblTextMeText(UserId,TextMsg,TextTime,TextDate) values ('"+id+"','"+msg+"',curtime(),curdate())";
		statement.executeUpdate(query);
		query="select UserName,TextMsg,TextTime,TextDate from viewtextme where UserId='"+id+"'";
		preparestmnt=connect.prepareStatement(query);
		result=preparestmnt.executeQuery();
		while(result.next())
		{
			uname=result.getString(1);
			msg=result.getString(2);
			time=result.getString(3);
			date=result.getString(4);
		}
		return uname+","+msg+","+time+","+date;
	}
	public static ArrayList<String> showHistoryOfChatRoomDB() throws Exception
	{
		ArrayList<String> list = new ArrayList<String>();
		query="select UserName,TextMsg,TextTime,TextDate from viewtextme";
		preparestmnt=connect.prepareStatement(query);
		result=preparestmnt.executeQuery();
		while(result.next())
		{
			uname=result.getString(1);
			msg=result.getString(2);
			time=result.getString(3);
			date=result.getString(4);
			list.add(uname+","+msg+","+time+","+date);
		}
		return list;
	}
}




/*class ChatApplicationMain // Ashok Main
{
	public static void main(String args[]) throws Exception{

		ChatApplicationModel cam=new ChatApplicationModel();
		//ArrayList<ChatApplication> temp=new ArrayList<ChatApplication>();
		String p="Kumar";
		String id="John@tm.com";
		//String temp=cam.register(p,p,p);
		String temp2=cam.saveMsg(p,id);
		//for(ChatApplication ca:temp){
		//System.out.println(temp);
		System.out.println(temp2);	
		public ArrayList<ChatApplication> saveMsgIntoChatRoomDB(String id,String msg) throws Exception
	{
		query="insert into tblTextMeText(UserId,TextData,TextTime,TextDate) values ('"+id+"','"+msg+"',curtime(),curdate())";
		statement.executeUpdate(query);
		ArrayList<ChatApplication> list = new ArrayList<ChatApplication>();
		query="select * from viewtextme where UserId='"+id+"'";
		preparestmnt=connect.prepareStatement(query);
		result=preparestmnt.executeQuery();
		while(result.next())
		{
			num=result.getInt(1);
			id=result.getString(2);
			pwd=result.getString(3);
			uname=result.getString(4);
			date=result.getString(5);
			time=result.getString(6);
			msg=result.getString(7);
			list.add(new ChatApplication(num,id,pwd,uname,date,time,msg));
		}
		return list;
		// return "inserted successfully";
	}					
	}
	
}*/
// public class ChatApplicationMain // Monica Main
// {
// 	public static void main(String args[]){
// 		try
// 		{
// 		ChatApplicationModel cam=new ChatApplicationModel();
// 		String i="1";
// 		String p="p";
// 		String u="u";
// 		String id="John@tm.com";
// 		String data="hai";
// 		// ArrayList<ChatApplication> temp=new ArrayList<ChatApplication>();
// 		String temp=cam.register(i,p,u);
// 		// for(ChatApplication ca:temp){
// 			System.out.println(temp);		
// 			boolean status=cam.login(i,p);
// 			System.out.println(status);
// 			String t1=cam.InsertMessage(id,data);
// 			System.out.println(t1);

// 		// }
// 		}
// 		catch(Exception e)
// 		{
// 			System.out.print(e);
// 		}
// 	}
// }







