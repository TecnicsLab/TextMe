
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import Chat.ChatApplicationModel;
import Chat.ChatApplication;

public class LoginValidationServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
      	PrintWriter printer = response.getWriter();
      	boolean found=false;
		try
		{
			String get_id=request.getParameter("UserId");
			String get_pwd=request.getParameter("Password");
			ChatApplicationModel chatappmodel = new ChatApplicationModel();
			found= chatappmodel.loginValidationWithChatRoomDB(get_id,get_pwd);
			if(found)
			{
				HttpSession session = request.getSession(true);
				session.setAttribute("userid",get_id);
            	response.sendRedirect("http://localhost:8080/history");
    		}
    		else
    		{
    			printer.print("Sorry incorrect Userid or Password");  
    		}
    	}
    	catch(Exception error)
    	{
    		printer.println(error);
    	}
    }
}