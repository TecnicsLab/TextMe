
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import Chat.ChatApplicationModel;
import Chat.ChatApplication;

public class DisplayHistoryServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
      	PrintWriter printer = response.getWriter();
		try
		{
			ChatApplicationModel chatappmodel = new ChatApplicationModel();
			ArrayList<String> list=chatappmodel.showHistoryOfChatRoomDB();
			printer.println(list);
		}
		catch(Exception error)
		{
			printer.println(error);
		}
	}
}
