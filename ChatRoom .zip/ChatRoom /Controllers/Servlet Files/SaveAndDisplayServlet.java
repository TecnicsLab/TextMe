
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import Chat.ChatApplicationModel;
import Chat.ChatApplication;

public class SaveAndDisplayServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
      	PrintWriter printer = response.getWriter();
		try
		{
			HttpSession session = request.getSession(true);
			String user_id=(String)session.getAttribute("userid");
			String get_data=request.getParameter("msg");
			ChatApplicationModel chatappmodel = new ChatApplicationModel();
			String user_data= chatappmodel.saveMsgIntoChatRoomDB(user_id,get_data);
			printer.print(user_data);
		}
		catch(Exception error)
		{
			printer.print(error);
		}   			
	}
}